INSERT INTO books (titulo, autor, categoria, anio_publicacion) VALUES
('Don Quijote de la Mancha','Miguel de Cervantes','Novela',1605),
('Cien años de soledad','Gabriel García Márquez','Realismo mágico',1967),
('Clean Code','Robert C. Martin','Tecnología',2008),
('El señor de los anillos','J.R.R. Tolkien','Fantasía',1954);
