package com.example.bookapi;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/libros")
public class BookController {
    private final BookRepository repo;

    public BookController(BookRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Book> getAll() { return repo.findAll(); }

    @GetMapping("/{id}")
    public Book getById(@PathVariable Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Libro no encontrado"));
    }

    @GetMapping("/buscar/titulo")
    public List<Book> searchByTitulo(@RequestParam String q) {
        return repo.findByTituloContainingIgnoreCase(q);
    }

    @GetMapping("/buscar/autor")
    public List<Book> searchByAutor(@RequestParam String q) {
        return repo.findByAutorContainingIgnoreCase(q);
    }

    @GetMapping("/buscar/categoria")
    public List<Book> searchByCategoria(@RequestParam String q) {
        return repo.findByCategoriaContainingIgnoreCase(q);
    }

    @PostMapping
    public Book create(@RequestBody Book book) { return repo.save(book); }
}
